package oracle.jdbc.driver;

/**
 * A mocking class used as a placeholder for the real Oracle JDBC drivers to prevent build errors.
 */
public class OracleDriver {
    // no data
}
