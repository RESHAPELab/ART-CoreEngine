package org.jabref;

/**
 * JabRef Launcher
 */
public class JabRefLauncher {
    public static void main(String[] args) {
        JabRefMain.main(args);
    }
}
