---
name: Question
about: Ask a question about JabRef

---

Please use the GitHub issue tracker only for bug reports and suggestions for improvements.
Feature requests, questions and general feedback is now handled at http://discourse.jabref.org.
Thanks!
