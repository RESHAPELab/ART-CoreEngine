#!/bin/bash
wget --quiet -nc --show-progress https://download-gcdn.ej-technologies.com/install4j/install4j_unix_8_0.tar.gz
tar -xf install4j_unix_8_0.tar.gz
mv install4j8.0 install4j8
